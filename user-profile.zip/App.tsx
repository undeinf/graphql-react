import { FluentProvider, teamsLightTheme } from "@fluentui/react-components";
import { UserProfile } from "./user-profile/user-profile.component";

function App() {
  return (
    <div className="container">
      <FluentProvider theme={teamsLightTheme}>
        <UserProfile />
      </FluentProvider>
    </div>
  );
}

export default App;
