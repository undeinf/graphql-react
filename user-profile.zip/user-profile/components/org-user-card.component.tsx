import { Avatar, Image, Label, Text } from "@fluentui/react-components";
import { ArrowRightRegular } from "@fluentui/react-icons";
import styled from "styled-components";
import { ContactInfoType } from "../../types";

type Props = {
  role: string;
  title: string;
  showTailArrow?: boolean;
  childrenItems?: ContactInfoType[];
  showHover?:boolean
};

export const OrgUserCardComponent: React.FC<Props> = ({
  role,
  title,
  showTailArrow = true,
  childrenItems,
  showHover
}) => {
  // return (
  //     <div className="flex py-4 first:pt-0 last:pb-0 border">
  //         <Image className="h-10 w-10 rounded-full" alt="User Image" />
  //         <div className="ml-3 overflow:hidden">
  //         <p className="text-sm font-medium text-slate-900">{title}</p>
  //         <p className="text-sm truncate text-slate-900">{title}</p>
  //         </div>
  //     </div>
  // )

  return (
    <>
      <UserCard role={role} title={title} showTailArrow={showTailArrow} showHover={showHover} />
      <br/>
      {childrenItems && childrenItems.length > 0 && <div className="pt-2 border mb-6">
      <Text className="text-sm pl-2">You work with</Text>
      <div className="grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2 xs:grid-cols-1">
        
          {childrenItems.map((child) => {
            return <div className="p-3"><UserCard showTailArrow={false} role={child.role} title={child.title} /></div>;
          })}
      </div>
      </div>}
    </>
  );
};

const RelativeHover = styled.div`
  &:hover {
    .right-arrow {
      display: block;
    }
  }
  .right-arrow {
    display: none;
  }
`;

const UserCard: React.FC<Props> = ({ role, title, showTailArrow, showHover }) => {
  return (
    <RelativeHover className="relative w-[200px] " >
      <div className="flex items-center p-3 border hover:bg-slate-100">
        {/* <span className="pr-2">ICON</span> */}
        <Avatar className="mr-3" name={title} />
        <div className="flex flex-col">
          <Label>{title}</Label>
          <Text>{role}</Text>
        </div>
        <span className="absolute right-1 right-arrow">
          <ArrowRightRegular />
        </span>
      </div>
      {showTailArrow && (
        <div className="flex justify-center ">
          <span
            style={{
              borderRight: "1px solid #ccc",
              height: 15,
            }}
          ></span>
        </div>
      )}
    </RelativeHover>
  );
};
