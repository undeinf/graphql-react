import * as React from "react";
import {
  makeStyles,
  mergeClasses,
  shorthands,
  tokens,
  Button,
  Menu,
  MenuItem,
  MenuItemProps,
  MenuList,
  MenuPopover,
  MenuTrigger,
  Tab,
  TabList,
  useIsOverflowItemVisible,
  useOverflowMenu,
  Overflow,
  OverflowItem,
} from "@fluentui/react-components";
import {
  Calendar3DayRegular,
  CalendarAgendaRegular,
  CalendarChatRegular,
  CalendarDayRegular,
  CalendarMonthRegular,
  CalendarSearchRegular,
  CalendarTodayRegular,
  CalendarWeekStartRegular,
  CalendarWorkWeekRegular,
  MoreHorizontalRegular,
  Calendar3DayFilled,
  CalendarAgendaFilled,
  CalendarChatFilled,
  CalendarDayFilled,
  CalendarMonthFilled,
  CalendarSearchFilled,
  CalendarTodayFilled,
  CalendarWeekStartFilled,
  CalendarWorkWeekFilled,
  MoreHorizontalFilled,
  bundleIcon,
  ArrowDownloadRegular,
  ArrowDownRegular,
  ArrowSquareDownRegular,
  ChevronDownFilled,
} from "@fluentui/react-icons";
import styled from "styled-components";
import useWindowDimensions from "../hook/useWindowDimensions";
import { TabIdType } from "../../types";

const Calendar3Day = bundleIcon(Calendar3DayFilled, Calendar3DayRegular);
const CalendarAgenda = bundleIcon(CalendarAgendaFilled, CalendarAgendaRegular);
const CalendarChat = bundleIcon(CalendarChatFilled, CalendarChatRegular);
const CalendarDay = bundleIcon(CalendarDayFilled, CalendarDayRegular);
const CalendarMonth = bundleIcon(CalendarMonthFilled, CalendarMonthRegular);
const CalendarSearch = bundleIcon(CalendarSearchFilled, CalendarSearchRegular);
const CalendarToday = bundleIcon(CalendarTodayFilled, CalendarTodayRegular);
const CalendarWeekStart = bundleIcon(
  CalendarWeekStartFilled,
  CalendarWeekStartRegular
);
const CalendarWorkWeek = bundleIcon(
  CalendarWorkWeekFilled,
  CalendarWorkWeekRegular
);
const MoreHorizontal = bundleIcon(MoreHorizontalFilled, MoreHorizontalRegular);

//----- Example Tab Data -----//

type ExampleTab = {
  id: string;
  name: string;
  icon: React.ReactElement;
};

const tabs: ExampleTab[] = [
  {
    id: "today",
    name: "Today",
    icon: <CalendarToday />,
  },
  {
    id: "agenda",
    name: "Agenda",
    icon: <CalendarAgenda />,
  },
  {
    id: "day",
    name: "Day",
    icon: <CalendarDay />,
  },
  {
    id: "threeDay",
    name: "Three Day",
    icon: <Calendar3Day />,
  },
  {
    id: "workWeek",
    name: "Work Week",
    icon: <CalendarWorkWeek />,
  },
  {
    id: "week",
    name: "Week",
    icon: <CalendarWeekStart />,
  },
  {
    id: "month",
    name: "Month",
    icon: <CalendarMonth />,
  },
  {
    id: "search",
    name: "Search",
    icon: <CalendarSearch />,
  },
  {
    id: "chat",
    name: "Conversations",
    icon: <CalendarChat />,
  },
];

const profileTabs:ExampleTab[] = [
    {
        id: "contact",
        name: "Contact",
        icon: <CalendarToday />,
      },
      {
        id: "organization",
        name: "Organization",
        icon: <CalendarAgenda />,
      },
      // {
      //   id: "contact",
      //   name: "Contact",
      //   icon: <CalendarDay />,
      // },
]

//----- OverflowMenuItem -----//

type OverflowMenuItemProps = {
  tab: ExampleTab;
  onClick: MenuItemProps["onClick"];
};

/**
 * A menu item for an overflow menu that only displays when the tab is not visible
 */
const OverflowMenuItem = (props: OverflowMenuItemProps) => {
  const { tab, onClick } = props;
  const isVisible = useIsOverflowItemVisible(tab.id);

  if (isVisible) {
    return null;
  }

  return (
    <MenuItem key={tab.id} icon={tab.icon} onClick={onClick}>
      <div>{tab.name}</div>
    </MenuItem>
  );
};

//----- OverflowMenu -----//

const useOverflowMenuStyles = makeStyles({
  menu: {
    backgroundColor: tokens.colorNeutralBackground1,
  },
  menuButton: {
    alignSelf: "center",
  },
});

type OverflowMenuProps = {
  onTabSelect?: (tabId: TabIdType) => void;
};

/**
 * A menu for selecting tabs that have overflowed and are not visible.
 */
const OverflowMenu = (props: OverflowMenuProps) => {
  const { onTabSelect } = props;
  const { ref, isOverflowing, overflowCount } =
    useOverflowMenu<HTMLButtonElement>();

  const styles = useOverflowMenuStyles();

  const onItemClick = (tabId: string) => {
    onTabSelect?.(tabId as TabIdType);
  };

  if (!isOverflowing) {
    return null;
  }

  return (
    <Menu hasIcons>
      <MenuTrigger disableButtonEnhancement>
        <Button
          appearance="transparent"
          className={styles.menuButton}
          ref={ref}
          // icon={<MoreHorizontal />}
          icon={<ChevronDownFilled />}
          aria-label={`${overflowCount} more tabs`}
          role="tab"
        >{overflowCount} more</Button>
      </MenuTrigger>
      <MenuPopover>
        <MenuList className={styles.menu}>
          {profileTabs.map((tab) => (
            <OverflowMenuItem
              key={tab.id}
              tab={tab}
              onClick={() => onItemClick(tab.id)}
            />
          ))}
        </MenuList>
      </MenuPopover>
    </Menu>
  );
};

//----- Stories -----//

const useExampleStyles = makeStyles({
  example: {
    // backgroundColor: tokens.colorNeutralBackground2,
    ...shorthands.overflow("hidden"),
    ...shorthands.padding("5px"),
    zIndex: 0, //stop the browser resize handle from piercing the overflow menu
  },
  horizontal: {
    height: "fit-content",
    // minWidth: "100px",
    // resize: "horizontal",
    // width: "300px",
  },
});

const HorizontalExample:React.FC<{onChange:(tabId:TabIdType) => void}> = ({
  onChange
}) => {
  const styles = useExampleStyles();
  const {width} = useWindowDimensions();

  const [selectedTabId, setSelectedTabId] = React.useState<string>("contact");

  const onTabSelect = (tabId: TabIdType) => {
    setSelectedTabId(tabId);
    onChange(tabId);
  };

  return (
    <div className={mergeClasses(styles.example, styles.horizontal)}>
      <OverflowStyled minimumVisible={1}   >
        <TabList
            className="tab-list-class"
          selectedValue={selectedTabId}
          style={{
            width: 250
          }}
          onTabSelect={(_, d) => {
            onTabSelect(d.value as TabIdType)
          }}
        >
          {profileTabs.map((tab) => {
            return (
              <OverflowItem
                key={tab.id}
                id={tab.id}
                priority={tab.id === selectedTabId ? 2 : 1}
              >
                {/* <div className={mergeClasses(resizableStyles.container, resizableStyles.resizableArea)}> */}
                <Tab value={tab.id} icon={<span>{tab.icon}</span>}>
                  {tab.name}
                </Tab>
                {/* </div> */}
              </OverflowItem>
            );
          })}
          <OverflowMenu onTabSelect={onTabSelect} />
        </TabList>
      </OverflowStyled>
    </div>
  );
};


const useStyles = makeStyles({
  root: {
    alignItems: "flex-start",
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    ...shorthands.overflow("auto"),
    // ...shorthands.padding("50px", "20px"),
    paddingTop: 0,
    paddingLeft: 0,
    rowGap: "20px",
    // minHeight: "600px", //lets the page remain at a minimum height when vertical tabs are resized
  },
});
export const TabsComponent:React.FC<{onChange:(tabId:TabIdType) => void}> = ({
  onChange
}) => {
  const styles = useStyles();

  return (
    <div className={styles.root}>
      <HorizontalExample onChange={onChange}/>
      {/* <VerticalExample /> */}
    </div>
  );
};


const OverflowStyled = styled(Overflow)`
    background: green;
`