import { Label, Text } from "@fluentui/react-components"

type Props = {
    label:string;
    value:string;
    icon?:React.ReactElement;
    isClickable?:boolean;
    onClick?:() => void;
}

export const UserInfoCard:React.FC<Props> = ({
    label,
    value,
    icon,
    isClickable,
    onClick
}) => {
    return <div className="flex items-center p-3">
        <span className="pr-2" onClick={() => {
            if(isClickable && onClick) onClick();
        }}>{icon}</span>
        <div className="flex flex-col">
            <Label>{label}</Label>
            <Text className={`${isClickable ? 'cursor-pointer text-blue-500 hover:text-blue-700 hover:underline' : ''}`}>{value}</Text>
        </div>

    </div>
}