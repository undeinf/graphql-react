import {
  BuildingRegular,
  CallRegular,
  ChatRegular,
  LocationRegular,
  MailRegular,
  PeopleAudienceRegular,
  PersonRegular,
  ViewDesktopMobileFilled,
} from "@fluentui/react-icons";
import { UserContactType } from "../../types";
import { UserInfoCard } from "./user-info-card.component";
import { useMemo } from "react";
import { Text } from "@fluentui/react-components";

type Props = {
  userInfo: UserContactType;
  showMore:boolean;
  setShowMore:(flag:boolean) => void
};

export const UserInformationComponent: React.FC<Props> = ({ userInfo, showMore, setShowMore }) => {
  

  const userInfoMemo = useMemo(() => {
    if (!userInfo) {
      return <></>;
    }
    return (
      <>
        <UserInfoCard
          icon={<MailRegular />}
          label="Email"
          value={userInfo.email}
          isClickable
        />

        <UserInfoCard
          icon={<ChatRegular />}
          label="Chat"
          value={userInfo.chat}
          isClickable
        />

        <UserInfoCard
          icon={<CallRegular />}
          label="Work phone"
          value={userInfo.workPhone}
          isClickable
        />

        <UserInfoCard
          icon={<ViewDesktopMobileFilled />}
          label="Mobile"
          value={userInfo.mobile}
          isClickable
        />

        <UserInfoCard
          icon={<LocationRegular />}
          label="Location"
          value={userInfo.location}
        />

        <UserInfoCard
          icon={<BuildingRegular />}
          label="Company"
          value={userInfo.company}
        />

        <UserInfoCard
          icon={<PersonRegular />}
          label="Job title"
          value={userInfo.jobRole}
        />

        <UserInfoCard
          icon={<PeopleAudienceRegular />}
          label="Department"
          value={userInfo.department}
        />

        <UserInfoCard
          icon={<LocationRegular />}
          label="Business address"
          value={userInfo.businessAddress}
        />
      </>
    );
  }, [userInfo]);
  return (
    <div>
      <div className="grid grid-cols-3 max-md:grid-cols-2 max-sm:grid-cols-1">
        {userInfoMemo}

        {showMore && userInfoMemo}
      </div>
      {!showMore && (
        <div className="flex justify-end w-full">
        <Text className="  text-blue-500 hover:text-blue-700 cursor-pointer " onClick={() => setShowMore(true)}>
          show more?
        </Text>
        </div>
      )}
    </div>
  );
};
