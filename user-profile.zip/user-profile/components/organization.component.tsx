import { useMemo } from "react";
import { OrgUserCardComponent } from "./org-user-card.component";
import { RelationType } from "../../types";

export const OrganizationComponent:React.FC<{}> = () => {
    const relations = useMemo<RelationType[]>(() => {
        return [
            {
                title: "User 1",
                role: "Chilef 1"
            },
            {
                title: "User 2",
                role: "Chilef 2"
            },
            {
                title: "User 3",
                role: "Chilef 3"
            },
            {
                title: "User 4",
                role: "Chilef 4"
            },
            {
                title: "User 5",
                role: "Chilef 5"
            },
            {
                title: "User 6",
                role: "Chilef 6"
            },
            {
                title: "User 7",
                role: "Chilef 7",
                children: [
                    {
                        title: "Child 1",
                        role: "Head 1"
                    },
                    {
                        title: "Child 2",
                        role: "Head 2"
                    },
                    {
                        title: "Child 3",
                        role: "Head 3"
                    },
                    {
                        title: "Child 4",
                        role: "Head 4"
                    },
                    {
                        title: "Child 5",
                        role: "Head 5"
                    },
                    {
                        title: "Child 6",
                        role: "Head 6"
                    },
                    {
                        title: "Child 7",
                        role: "Head 7"
                    },
                ]
            },
        ]
        // return [];
    },[])
    return <div className="flex items-center flex-col w-full">
        {relations.map((item) => (
            <OrgUserCardComponent
                role={item.role}
                title={item.title}
                showTailArrow={item && item.children && item.children.length === 0}
                childrenItems={item?.children || []}
            />
        ))}
    </div>
}