import { Persona, Text } from "@fluentui/react-components";
import { TabsComponent } from "./components/tabs.components";
import {
  ChatRegular,
  FeedRegular,
  LightbulbFilamentRegular,
  MailRegular,
} from "@fluentui/react-icons";
import { useState } from "react";
import { TabIdType, UserContactType } from "../types";
import { UserInformationComponent } from "./components/user-information.component";
import { OrganizationComponent } from "./components/organization.component";

const userContactInfor: UserContactType = {
  businessAddress: "Madhupur / Hydrabad Rangareddy",
  department: "IES - Digital Platform Svce  Office 365",
  jobRole: "Assoc. Dir. DCNT IES O365 Real Time Ops",
  company: "Novartis Healcare Pvt. Ltd.",
  location: "-/-/ Hydrabad",
  mobile: "+911234567890",
  workPhone: "+914040404040",
  chat: "abc.123@novartis.com",
  email: "abc.123@novartis.com",
};

export const UserProfile: React.FC<{}> = () => {
  const [tabId, setTabId] = useState<TabIdType>("contact");
  const [showMore, setShowMore] = useState<boolean>(false);
  return (
    <div className="pt-6">
      <div>
        <section about="user frequest information">
          <div className="">
            <Persona
              size="huge"
              name="Shaw, Ritesh Kumar"
              avatar={{ color: "colorful" }}
              secondaryText={
                <span className="flex flex-col">
                  <Text>Sr. Soec, DDUT IES O365 Cikkab Eng.</Text>
                  <div className="flex pt-1">
                    <MailRegular className="mr-2 hover:cursor-pointer" onClick={() => {
                        window.location.href = `mailto:testmail@test.co?subject=${encodeURIComponent('pls assign complext task to me')}&body=${encodeURIComponent("dont dare to delete the subject!!!")}`
                    }}/>
                    <ChatRegular />
                  </div>
                </span>
              }
            />
          </div>
        </section>
        <section about="tab toolbar">
          
          <div className="flex justify-between items-baseline max-[320px]:flex-col">
            <TabsComponent onChange={(tabId) => setTabId(tabId)}  />
            <div style={{
                // minWidth: 200
            }}>
              <div className="flex w-full justify-end  max-[320px]:py-3">
                <span className="flex justify-center pr-3 ">
                  <FeedRegular className="mr-1 mt-1"/>
                  <Text className="max-[480px]:!hidden max-[320px]:!block">Feebback</Text>
                </span>
                <span className="flex justify-center">
                  <LightbulbFilamentRegular  className="mr-1 mt-1"/>
                  <Text className="max-[480px]:!hidden max-[320px]:!block">Search Tips</Text>
                  
                </span>
              </div>
            </div>
          </div>
        </section>

        {tabId === "contact" && (
        <section about="user details">
          <UserInformationComponent 
            userInfo={userContactInfor} 
            showMore={showMore}    
            setShowMore={(flag:boolean) => setShowMore(flag)}
            
        />
        </section>
        )}

        {tabId === "organization" && (
            <section about="organization detail">
                <OrganizationComponent />
            </section>
        )}
      </div>
    </div>
  );
};
