export type UserContactType = {
    email:string;
    chat:string;
    workPhone:string;
    mobile:string;
    location:string;
    company:string;
    jobRole:string;
    department:string;
    businessAddress:string;
}

export type TabIdType = "contact" | "organization";


export type ContactInfoType = {
    title:string;
    role:string;
}

export type RelationType = {
    children?:ContactInfoType[]
} & ContactInfoType
