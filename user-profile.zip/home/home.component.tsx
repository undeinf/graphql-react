import { UserProfile } from "../user-profile/user-profile.component"


export const HomeComponent:React.FC<{}> = () => {
    return <UserProfile />
}